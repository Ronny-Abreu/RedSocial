
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `publicaciones`
--

DROP TABLE IF EXISTS `publicaciones`;
CREATE TABLE `publicaciones` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `contenido` text NOT NULL,
  `fecha_publicacion` datetime DEFAULT current_timestamp(),
  `compartidos` int(11) DEFAULT 0,
  `privacidad` enum('público','privado','Mejores Amigos') DEFAULT 'público',
  `contador_comentarios` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `publicaciones`
--

INSERT INTO `publicaciones` VALUES
(1, 1, 'Mi primer post en la red!', '2025-03-20 16:56:04', 2, 'público', 1),
(2, 2, 'Hermosa vista desde la montaña!', '2025-03-20 16:56:04', 5, 'público', 1),
(3, 3, 'Recomendaciones de películas?', '2025-03-20 16:56:04', 1, 'privado', 1),
(4, 4, 'Nuevo libro favorito!', '2025-03-20 16:56:04', 0, 'público', 1),
(5, 5, 'Fotos de mi último viaje.', '2025-03-20 16:56:04', 3, 'Mejores Amigos', 1),
(6, 6, 'Iniciando en el mundo de la programación!', '2025-03-20 16:56:04', 10, 'Mejores Amigos', 1),
(7, 7, '¿Alguien más ama los videojuegos retro?', '2025-03-20 16:56:04', 7, 'Mejores Amigos', 1),
(8, 8, 'Consejos para cuidar a un cachorro?', '2025-03-20 16:56:04', 4, 'privado', 1),
(9, 9, 'Mañana haré mi primera maratón!', '2025-03-20 16:56:04', 3, 'público', 1),
(11, 11, 'Descubrí un nuevo planeta en el telescopio!', '2025-03-20 16:56:04', 5, 'Mejores Amigos', 1),
(12, 12, 'Practicando yoga todas las mañanas!', '2025-03-20 16:56:04', 3, 'público', 1),
(13, 13, 'Aprendiendo alemán! Es difícil pero emocionante.', '2025-03-20 16:56:04', 2, 'público', 1),
(14, 14, 'Jugué mi mejor partida de ajedrez hoy!', '2025-03-20 16:56:04', 1, 'privado', 1),
(15, 15, 'Nuevo outfit para la fiesta.', '2025-03-20 16:56:04', 6, 'público', 1),
(16, 16, 'Concierto increíble anoche!', '2025-03-20 16:56:04', 9, 'público', 1),
(17, 17, 'Probando nuevas funciones en Python.', '2025-03-20 16:56:04', 4, 'público', 1),
(18, 18, 'Buscando recomendaciones de libros.', '2025-03-20 16:56:04', 3, 'público', 1),
(19, 19, 'Primera vez que toco la guitarra en público!', '2025-03-20 16:56:04', 7, 'público', 1);
