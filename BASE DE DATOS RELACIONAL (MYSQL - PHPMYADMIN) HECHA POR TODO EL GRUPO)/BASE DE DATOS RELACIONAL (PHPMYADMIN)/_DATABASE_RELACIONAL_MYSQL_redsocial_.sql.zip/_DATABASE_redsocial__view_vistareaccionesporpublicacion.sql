
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistareaccionesporpublicacion` exportada como una tabla
--
DROP TABLE IF EXISTS `vistareaccionesporpublicacion`;
CREATE TABLE`vistareaccionesporpublicacion`(
    `publicacion_id` int(11) DEFAULT NULL,
    `contenido_publicacion` text COLLATE utf8mb4_general_ci NOT NULL,
    `tipo` enum('Me gusta','Me encanta','Me divierte','Me asombra','Me entristece','Me enoja') COLLATE utf8mb4_general_ci NOT NULL,
    `cantidad` bigint(21) NOT NULL DEFAULT '0'
);
