
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `amistades`
--

DROP TABLE IF EXISTS `amistades`;
CREATE TABLE `amistades` (
  `id` int(11) NOT NULL,
  `usuario1_id` int(11) NOT NULL,
  `usuario2_id` int(11) NOT NULL,
  `estado` enum('pendiente','aceptado','bloqueado') DEFAULT 'pendiente',
  `fecha_solicitud` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `amistades`
--

INSERT INTO `amistades` VALUES
(1, 1, 2, 'aceptado', '2025-03-20 17:13:56'),
(2, 2, 3, 'pendiente', '2025-03-20 17:13:56'),
(3, 3, 4, 'aceptado', '2025-03-20 17:13:56'),
(4, 4, 5, 'bloqueado', '2025-03-20 17:13:56'),
(5, 5, 6, 'pendiente', '2025-03-20 17:13:56'),
(6, 6, 7, 'aceptado', '2025-03-20 17:13:56'),
(7, 7, 8, 'pendiente', '2025-03-20 17:13:56'),
(8, 8, 9, 'aceptado', '2025-03-20 17:13:56'),
(9, 9, 10, 'pendiente', '2025-03-20 17:13:56'),
(10, 10, 11, 'aceptado', '2025-03-20 17:13:56'),
(11, 11, 12, 'pendiente', '2025-03-20 17:13:56'),
(12, 12, 13, 'aceptado', '2025-03-20 17:13:56'),
(13, 13, 14, 'pendiente', '2025-03-20 17:13:56'),
(14, 14, 15, 'aceptado', '2025-03-20 17:13:56'),
(15, 15, 16, 'pendiente', '2025-03-20 17:13:56'),
(16, 16, 17, 'aceptado', '2025-03-20 17:13:56'),
(17, 17, 18, 'pendiente', '2025-03-20 17:13:56'),
(18, 18, 19, 'aceptado', '2025-03-20 17:13:56');
