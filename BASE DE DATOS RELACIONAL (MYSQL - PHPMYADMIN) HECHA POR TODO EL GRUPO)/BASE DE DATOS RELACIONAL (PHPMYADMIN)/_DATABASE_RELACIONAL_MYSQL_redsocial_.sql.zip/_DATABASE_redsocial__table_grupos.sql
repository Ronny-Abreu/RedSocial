
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `grupos`
--

DROP TABLE IF EXISTS `grupos`;
CREATE TABLE `grupos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT current_timestamp(),
  `privacidad` enum('público','privado') DEFAULT 'público',
  `creador_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `grupos`
--

INSERT INTO `grupos` VALUES
(1, 'Aventureros', 'Grupo para compartir experiencias de viaje.', '2025-03-20 17:16:16', 'público', 1),
(2, 'Lectores Nocturnos', 'Club de lectura para noctámbulos.', '2025-03-20 17:16:16', 'privado', 2),
(3, 'Techies', 'Espacio para discutir sobre tecnología y gadgets.', '2025-03-20 17:16:16', 'público', 3),
(4, 'Cinefilia', 'Amantes del cine clásico y moderno.', '2025-03-20 17:16:16', 'privado', 4),
(5, 'Cocina Creativa', 'Recetas y tips culinarios innovadores.', '2025-03-20 17:16:16', 'público', 5),
(6, 'Músicos Unidos', 'Comunidad para músicos de todos los géneros.', '2025-03-20 17:16:16', 'privado', 6),
(7, 'Deportistas Extremos', 'Para quienes buscan aventuras deportivas.', '2025-03-20 17:16:16', 'público', 7),
(8, 'Fotografía Artística', 'Espacio para compartir y aprender fotografía.', '2025-03-20 17:16:16', 'privado', 8),
(9, 'Viajeros del Mundo', 'Conexión para quienes aman explorar nuevos destinos.', '2025-03-20 17:16:16', 'público', 9),
(10, 'Amigos de los Animales', 'Grupo dedicado al cuidado y bienestar animal.', '2025-03-20 17:16:16', 'privado', 10),
(11, 'Cine Independiente', 'Debates y recomendaciones sobre cine independiente.', '2025-03-20 17:16:16', 'público', 11),
(12, 'Gastronomía Global', 'Explorando sabores de todo el mundo.', '2025-03-20 17:16:16', 'privado', 12),
(13, 'Innovadores Tecnológicos', 'Para discutir las últimas tendencias en tecnología.', '2025-03-20 17:16:16', 'público', 13),
(14, 'Club de Poesía', 'Espacio para compartir y analizar poesía.', '2025-03-20 17:16:16', 'privado', 14),
(15, 'Aficionados al Vino', 'Catas y discusiones sobre vinos de diferentes regiones.', '2025-03-20 17:16:16', 'público', 15),
(16, 'Cultura Pop', 'Debates sobre series, películas y música popular.', '2025-03-20 17:16:16', 'privado', 16),
(17, 'Ecologistas Unidos', 'Iniciativas y discusiones sobre medio ambiente.', '2025-03-20 17:16:16', 'público', 17),
(18, 'Emprendedores Creativos', 'Red de apoyo para emprendedores innovadores.', '2025-03-20 17:16:16', 'privado', 18),
(19, 'Ciclismo Urbano', 'Para amantes del ciclismo en la ciudad.', '2025-03-20 17:16:16', 'público', 19);
