
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(55) NOT NULL,
  `username` varchar(20) NOT NULL,
  `genero` enum('Masculino','Femenino','Otro') NOT NULL,
  `biografia` varchar(250) DEFAULT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `estado` enum('activo','suspendido','bloqueado') DEFAULT 'activo',
  `fecha_nacimiento` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` VALUES
(1, 'Juan Pérez', 'juanp', 'Masculino', 'Amante del fútbol.', 'juanp@mail.com', '9b8769a4a742959a2d0298c36fb70623f2dfacda8436237df08d8dfd5b37374c', 'activo', '1995-03-15'),
(2, 'María Gómez', 'mariag', 'Femenino', 'Me encanta viajar.', 'mariag@mail.com', '1d4598d1949b47f7f211134b639ec32238ce73086a83c2f745713b3f12f817e5', 'activo', '1992-07-21'),
(3, 'Carlos López', 'carlosl', 'Masculino', 'Cine y tecnología.', 'carlosl@mail.com', '9dbd5c893b5b573a1aa909c8cade58df194310e411c590d9fb0d63431841fd67', 'activo', '1988-11-03'),
(4, 'Ana Torres', 'anatorres', 'Femenino', 'Amante de los libros.', 'ana@mail.com', '2bd2a833384945be5a4d05109f418acbc78cc41d7640842f0e881ba892651296', 'suspendido', '1999-05-29'),
(5, 'Pedro Díaz', 'pedrod', 'Masculino', 'Fotógrafo aficionado.', 'pedro@mail.com', 'b5cef39c429c739f715624213d975b1b5faca8323f2f0a2efbb98f39c5a44c09', 'suspendido', '1990-12-10'),
(6, 'Lucía Fernández', 'luciaf', 'Femenino', 'Música y arte.', 'lucia@mail.com', 'd924bfbbcca7ada7599a1ef13ac11caf6a732e46306e5310b03c1b6563633bb2', 'activo', '2000-06-25'),
(7, 'Javier Ortega', 'javiero', 'Masculino', 'Fanático de los videojuegos.', 'javier@mail.com', 'c189638f276c83dc521375e433c348a81b538359b38ca76b5a17948c21387dac', 'activo', '1993-09-08'),
(8, 'Sofía Herrera', 'sofiaher', 'Femenino', 'Amante de los animales.', 'sofia@mail.com', '67523cdf844c76851a4e8f2e45e68f35faa010f5e7832e24a164c73ebc8a55ff', 'activo', '1997-04-14'),
(9, 'Andrés Castro', 'andresc', 'Masculino', 'Runner y montañista.', 'andres@mail.com', '3f1bd40d7baaec2b7480777267c50e3041671739aefcb2c12d14371b66dc562b', 'activo', '1991-01-31'),
(10, 'Paula Rojas', 'paular', 'Femenino', 'Cocina y repostería.', 'paula@mail.com', '540bb03f8d483b507f46ff1c4fb67f57c00c24fec4b7fe254a157e3ed072b1c6', 'activo', '1985-08-20'),
(11, 'David Salazar', 'davids', 'Masculino', 'Apasionado por la programación.', 'david@mail.com', '148e4d506e85edbde2f56da5e339f89aa68cb6a60082132394bd0956052e5d55', 'activo', '1994-12-05'),
(12, 'Elena Cruz', 'elenac', 'Femenino', 'Yoga y meditación.', 'elena@mail.com', 'd8e935eb1eafecd0d66463861b067dfc6e098cca210bcc615a0b71d0939bd662', 'activo', '1987-03-11'),
(13, 'Sergio Mendoza', 'sergiom', 'Masculino', 'Me gusta el ajedrez.', 'sergio@mail.com', 'b2c56341cc2b9f8bf898bd7528dd39e641b51c4fbd51f241b46ad70872dd1b99', 'activo', '1995-09-17'),
(14, 'Camila Duarte', 'camilad', 'Femenino', 'Aprendiendo idiomas.', 'camila@mail.com', '0be5449fd7e110e562888c7f6b2ceac607083936e4a8f286fcf9a2d672f73135', 'activo', '1998-12-24'),
(15, 'Fernando Ruiz', 'fernandor', 'Masculino', 'Aficionado a la astronomía.', 'fernando@mail.com', '82cc50ae50f2c39014ef7b995bd1050f2638a836a9e0a123088d670dfd5f2ca8', 'activo', '1990-05-30'),
(16, 'Gabriela Soto', 'gabrielas', 'Femenino', 'Me encanta la moda.', 'gabriela@mail.com', 'ae4b6c9d91b55bc6be8ff9b16057c96a72af85a872cf4505bea9a0b6cff2a65f', 'activo', '2001-06-18'),
(17, 'Roberto Vargas', 'robertov', 'Masculino', 'Músico de corazón.', 'roberto@mail.com', '5c892e4e93c63f9da889313ab652cc504d88dad1844cfcef1840968f9d79e65d', 'activo', '1986-10-05'),
(18, 'Angela Morales', 'angelam', 'Femenino', 'Fanática de la tecnología.', 'angela@mail.com', '632fc5e020ce7727544d1e72c85eef818fc3a9cae7de4240e0016fc44c3cc5a8', 'activo', '1993-07-08'),
(19, 'Cristian López', 'cristianl', 'Masculino', 'Guitarrista y viajero.', 'cristian@mail.com', '9a6361043893073e0359c0c3b525d02d29fb63314d646c11015b54953eedfa61', 'activo', '1997-11-22');

--
-- Disparadores `usuarios`
--
DROP TRIGGER IF EXISTS `after_usuario_delete`;
DELIMITER $$
CREATE TRIGGER `after_usuario_delete` AFTER DELETE ON `usuarios` FOR EACH ROW BEGIN
    DELETE FROM Amistades WHERE usuario1_id = OLD.id OR usuario2_id = OLD.id;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `before_usuario_insert`;
DELIMITER $$
CREATE TRIGGER `before_usuario_insert` BEFORE INSERT ON `usuarios` FOR EACH ROW BEGIN
    DECLARE correo_existente INT;
    SET correo_existente = (SELECT COUNT(*) FROM Usuarios WHERE correo = NEW.correo);
    IF correo_existente > 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El correo electrónico ya está registrado.';
    END IF;
END
$$
DELIMITER ;
