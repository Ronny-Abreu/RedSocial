
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistacomentariosporpublicacion` exportada como una tabla
--
DROP TABLE IF EXISTS `vistacomentariosporpublicacion`;
CREATE TABLE`vistacomentariosporpublicacion`(
    `publicacion_id` int(11) NOT NULL,
    `contenido_publicacion` text COLLATE utf8mb4_general_ci NOT NULL,
    `comentario_id` int(11) NOT NULL DEFAULT '0',
    `contenido_comentario` text COLLATE utf8mb4_general_ci NOT NULL,
    `nombre_comentario_usuario` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `fecha_comentario` datetime DEFAULT 'current_timestamp()'
);
