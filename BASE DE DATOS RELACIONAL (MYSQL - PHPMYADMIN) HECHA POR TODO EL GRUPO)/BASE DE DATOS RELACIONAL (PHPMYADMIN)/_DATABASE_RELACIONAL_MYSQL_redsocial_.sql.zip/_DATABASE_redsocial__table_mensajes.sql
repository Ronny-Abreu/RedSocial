
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

DROP TABLE IF EXISTS `mensajes`;
CREATE TABLE `mensajes` (
  `id` int(11) NOT NULL,
  `remitente_id` int(11) NOT NULL,
  `destinatario_id` int(11) NOT NULL,
  `contenido` text NOT NULL,
  `fecha_envio` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` VALUES
(1, 1, 2, 'Hola, ¿cómo estás?', '2025-03-20 17:14:36'),
(2, 2, 3, '¿Te gustaría salir este fin de semana?', '2025-03-20 17:14:36'),
(3, 3, 4, 'Tengo novedades sobre el proyecto.', '2025-03-20 17:14:36'),
(4, 4, 5, '¿Leíste el artículo que te recomendé?', '2025-03-20 17:14:36'),
(5, 5, 6, '¡Felicidades por tu logro!', '2025-03-20 17:14:36'),
(6, 6, 7, '¿Cuándo nos vemos para la práctica?', '2025-03-20 17:14:36'),
(7, 7, 8, 'Necesito tu opinión sobre este tema.', '2025-03-20 17:14:36'),
(8, 8, 9, '¿Te unes al plan para el viernes?', '2025-03-20 17:14:36'),
(9, 9, 10, 'Reenvío el documento que solicitaste.', '2025-03-20 17:14:36'),
(10, 10, 11, '¿Confirmas tu asistencia al evento?', '2025-03-20 17:14:36'),
(11, 11, 12, 'Recordatorio de la reunión de mañana.', '2025-03-20 17:14:36'),
(12, 12, 13, 'Gracias por tu ayuda en el proyecto.', '2025-03-20 17:14:36'),
(13, 13, 14, '¿Tienes disponibilidad para una llamada?', '2025-03-20 17:14:36'),
(14, 14, 15, 'Te envío las fotos del viaje.', '2025-03-20 17:14:36'),
(15, 15, 16, '¿Cómo va todo con el nuevo trabajo?', '2025-03-20 17:14:36'),
(16, 16, 17, 'Confirmado, nos vemos a las 6 PM.', '2025-03-20 17:14:36'),
(17, 17, 18, 'Adjunto el informe que pediste.', '2025-03-20 17:14:36'),
(18, 18, 19, '¿Puedes revisar este documento?', '2025-03-20 17:14:36'),
(21, 1, 2, 'Hola corazón, ¿cómo estás?', '2025-03-20 17:59:17'),
(22, 1, 2, 'Hola, ¿cómo estás?', '2025-04-01 22:02:11');
