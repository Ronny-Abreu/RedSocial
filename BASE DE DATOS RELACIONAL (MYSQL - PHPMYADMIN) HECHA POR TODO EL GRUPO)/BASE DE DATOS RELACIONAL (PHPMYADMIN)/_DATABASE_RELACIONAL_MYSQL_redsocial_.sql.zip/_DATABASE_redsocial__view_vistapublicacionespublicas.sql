
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistapublicacionespublicas` exportada como una tabla
--
DROP TABLE IF EXISTS `vistapublicacionespublicas`;
CREATE TABLE`vistapublicacionespublicas`(
    `id` int(11) NOT NULL DEFAULT '0',
    `usuario_id` int(11) NOT NULL,
    `nombre_usuario` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `contenido` text COLLATE utf8mb4_general_ci NOT NULL,
    `fecha_publicacion` datetime DEFAULT 'current_timestamp()'
);
