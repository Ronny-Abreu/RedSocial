
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_grupos`
--

DROP TABLE IF EXISTS `usuarios_grupos`;
CREATE TABLE `usuarios_grupos` (
  `id` int(11) NOT NULL,
  `grupo_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `rol` enum('admin','miembro') DEFAULT 'miembro',
  `fecha_union` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios_grupos`
--

INSERT INTO `usuarios_grupos` VALUES
(1, 1, 1, 'admin', '2025-03-20 17:17:13'),
(2, 1, 2, 'miembro', '2025-03-20 17:17:13'),
(3, 1, 3, 'miembro', '2025-03-20 17:17:13'),
(4, 2, 2, 'admin', '2025-03-20 17:17:13'),
(5, 2, 3, 'miembro', '2025-03-20 17:17:13'),
(6, 2, 4, 'miembro', '2025-03-20 17:17:13'),
(7, 3, 3, 'admin', '2025-03-20 17:17:13'),
(8, 3, 4, 'miembro', '2025-03-20 17:17:13'),
(9, 3, 5, 'miembro', '2025-03-20 17:17:13'),
(10, 4, 4, 'admin', '2025-03-20 17:17:13'),
(11, 4, 5, 'miembro', '2025-03-20 17:17:13'),
(12, 4, 6, 'miembro', '2025-03-20 17:17:13'),
(13, 5, 5, 'admin', '2025-03-20 17:17:13'),
(14, 5, 6, 'miembro', '2025-03-20 17:17:13'),
(15, 5, 7, 'miembro', '2025-03-20 17:17:13'),
(16, 6, 6, 'admin', '2025-03-20 17:17:13'),
(17, 6, 7, 'miembro', '2025-03-20 17:17:13'),
(18, 6, 8, 'miembro', '2025-03-20 17:17:13'),
(19, 7, 7, 'admin', '2025-03-20 17:17:13'),
(20, 7, 8, 'miembro', '2025-03-20 17:17:13'),
(21, 7, 9, 'miembro', '2025-03-20 17:17:13'),
(22, 2, 5, 'miembro', '2025-03-20 18:00:52');
