
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistamensajesentreusuarios` exportada como una tabla
--
DROP TABLE IF EXISTS `vistamensajesentreusuarios`;
CREATE TABLE`vistamensajesentreusuarios`(
    `id` int(11) NOT NULL DEFAULT '0',
    `remitente` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `destinatario` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `contenido` text COLLATE utf8mb4_general_ci NOT NULL,
    `fecha_envio` datetime DEFAULT 'current_timestamp()'
);
