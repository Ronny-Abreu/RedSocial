
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistausuariosactivos` exportada como una tabla
--
DROP TABLE IF EXISTS `vistausuariosactivos`;
CREATE TABLE`vistausuariosactivos`(
    `id` int(11) NOT NULL DEFAULT '0',
    `nombre` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `username` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
    `correo` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
    `fecha_nacimiento` date NOT NULL
);
