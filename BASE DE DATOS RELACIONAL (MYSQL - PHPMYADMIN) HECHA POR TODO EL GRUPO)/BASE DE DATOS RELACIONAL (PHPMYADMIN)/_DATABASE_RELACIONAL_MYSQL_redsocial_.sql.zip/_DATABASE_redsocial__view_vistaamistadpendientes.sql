
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistaamistadpendientes` exportada como una tabla
--
DROP TABLE IF EXISTS `vistaamistadpendientes`;
CREATE TABLE`vistaamistadpendientes`(
    `id` int(11) NOT NULL DEFAULT '0',
    `solicitante` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `solicitado` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `fecha_solicitud` datetime DEFAULT 'current_timestamp()'
);
