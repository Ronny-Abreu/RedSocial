
-- --------------------------------------------------------

--
-- Estructura para la vista de `vistamiembrosdegrupos` exportada como una tabla
--
DROP TABLE IF EXISTS `vistamiembrosdegrupos`;
CREATE TABLE`vistamiembrosdegrupos`(
    `nombre_grupo` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
    `nombre_usuario` varchar(55) COLLATE utf8mb4_general_ci NOT NULL,
    `rol` enum('admin','miembro') COLLATE utf8mb4_general_ci DEFAULT 'miembro',
    `fecha_union` datetime DEFAULT 'current_timestamp()'
);
