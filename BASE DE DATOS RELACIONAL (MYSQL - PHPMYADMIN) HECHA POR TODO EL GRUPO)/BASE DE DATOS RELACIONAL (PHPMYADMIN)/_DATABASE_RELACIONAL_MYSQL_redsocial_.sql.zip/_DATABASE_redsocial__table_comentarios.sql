
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

DROP TABLE IF EXISTS `comentarios`;
CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `publicacion_id` int(11) NOT NULL,
  `contenido_comentario` text NOT NULL,
  `fecha_comentario` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` VALUES
(1, 1, 1, '¡Qué emocionante tu primer post!', '2025-03-20 16:56:26'),
(2, 2, 2, 'Esa vista es impresionante, ¿dónde es?', '2025-03-20 16:56:26'),
(3, 3, 3, 'Totalmente de acuerdo, ¿alguna recomendación?', '2025-03-20 16:56:26'),
(4, 4, 4, 'Leí ese libro, es fascinante.', '2025-03-20 16:56:26'),
(5, 5, 5, '¡Qué fotos tan increíbles de tu viaje!', '2025-03-20 16:56:26'),
(6, 6, 6, 'Bienvenido al mundo de la programación, es genial.', '2025-03-20 16:56:26'),
(7, 7, 7, 'Los videojuegos retro tienen un encanto especial.', '2025-03-20 16:56:26'),
(8, 8, 8, 'Los cachorros son adorables, ¿qué raza es?', '2025-03-20 16:56:26'),
(9, 9, 9, '¡Mucho éxito en tu maratón!', '2025-03-20 16:56:26'),
(11, 11, 11, 'La astronomía es fascinante, ¿qué telescopio usas?', '2025-03-20 16:56:26'),
(12, 12, 12, 'El yoga ha cambiado mi vida, ¿qué estilo practicas?', '2025-03-20 16:56:26'),
(13, 13, 13, 'Aprender alemán es un reto, pero muy gratificante.', '2025-03-20 16:56:26'),
(14, 14, 14, 'El ajedrez es un juego de estrategia increíble.', '2025-03-20 16:56:26'),
(15, 15, 15, 'Ese conjunto es perfecto para la ocasión.', '2025-03-20 16:56:26'),
(16, 16, 16, '¿Dónde fue el concierto? Suena increíble.', '2025-03-20 16:56:26'),
(17, 17, 17, 'Python es muy versátil, ¿qué proyectos tienes en mente?', '2025-03-20 16:56:26'),
(18, 18, 18, 'Te recomiendo \"Cien años de soledad\", es un clásico.', '2025-03-20 16:56:26'),
(19, 19, 19, '¡Qué valiente al tocar en público!', '2025-03-20 16:56:26');

--
-- Disparadores `comentarios`
--
DROP TRIGGER IF EXISTS `after_comentario_insert`;
DELIMITER $$
CREATE TRIGGER `after_comentario_insert` AFTER INSERT ON `comentarios` FOR EACH ROW BEGIN
    UPDATE Publicaciones
    SET contador_comentarios = contador_comentarios + 1
    WHERE id = NEW.publicacion_id;
END
$$
DELIMITER ;
