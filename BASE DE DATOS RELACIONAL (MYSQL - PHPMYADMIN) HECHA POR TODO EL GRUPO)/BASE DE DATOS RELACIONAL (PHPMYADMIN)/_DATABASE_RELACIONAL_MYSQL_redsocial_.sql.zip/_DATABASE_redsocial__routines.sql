
DELIMITER $$
--
-- Procedimientos
--
DROP PROCEDURE IF EXISTS `agregar_reaccion`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `agregar_reaccion` (IN `usuario` INT, IN `publicacion` INT, IN `comentario` INT, IN `tipo_reaccion` ENUM('Me gusta','Me encanta','Me divierte','Me asombra','Me entristece','Me enoja'))   BEGIN
    -- Verificamos si la reacción es para una publicación o un comentario
    IF publicacion IS NOT NULL THEN
        INSERT INTO Reacciones (usuario_id, publicacion_id, tipo, fecha_reaccion)
        VALUES (usuario, publicacion, tipo_reaccion, CURRENT_TIMESTAMP);
    ELSE
        INSERT INTO Reacciones (usuario_id, comentario_id, tipo, fecha_reaccion)
        VALUES (usuario, comentario, tipo_reaccion, CURRENT_TIMESTAMP);
    END IF;
    
END$$

DROP PROCEDURE IF EXISTS `bloquear_usuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `bloquear_usuario` (IN `usuario_id` INT, IN `motivo` VARCHAR(100), IN `duracion` INT)   BEGIN
    -- Insertamos en la tabla de usuarioBloqueado
    INSERT INTO usuarioBloqueado (usuario_id, fecha_bloqueo, duracion_bloqueo, motivo)
    VALUES (usuario_id, CURRENT_TIMESTAMP, duracion, motivo);
    
    -- Cambiar el estado del usuario a 'bloqueado'
    UPDATE Usuarios
    SET estado = 'suspendido'
    WHERE id = usuario_id;
    
END$$

DROP PROCEDURE IF EXISTS `enviar_mensaje`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `enviar_mensaje` (IN `remitente` INT, IN `destinatario` INT, IN `mensaje_texto` TEXT)   BEGIN
    DECLARE mensaje_id INT;

    -- Insertar mensaje en la tabla de Mensajes
    INSERT INTO Mensajes (remitente_id, destinatario_id, contenido)
    VALUES (remitente, destinatario, mensaje_texto);
    
    -- Obtener el id del mensaje insertado
    SET mensaje_id = LAST_INSERT_ID();
    
    -- Insertar entrada en la tabla intermedia Usuarios_Mensajes
    INSERT INTO Usuarios_Mensajes (mensaje_id, destinatario_id, estado)
    VALUES (mensaje_id, destinatario, 'Enviado');
    
END$$

--
-- Funciones
--
DROP FUNCTION IF EXISTS `contar_amigos`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `contar_amigos` (`user_id` INT) RETURNS INT(11) DETERMINISTIC BEGIN  
    DECLARE total INT;  
    SELECT COUNT(*) INTO total  
    FROM amigos  
    WHERE usuario1_id = user_id OR usuario2_id = user_id;  
    RETURN total;  
END$$

DROP FUNCTION IF EXISTS `obtener_amigos`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `obtener_amigos` (`usuario_id` INT) RETURNS TEXT CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE amigos TEXT DEFAULT '';
    
    -- Obtenemos los amigos de la tabla de Amistades
    SELECT GROUP_CONCAT(username SEPARATOR ', ') INTO amigos
    FROM Usuarios
    WHERE id IN (
        SELECT usuario1_id FROM Amistades WHERE usuario2_id = usuario_id AND estado = 'aceptado'
        UNION
        SELECT usuario2_id FROM Amistades WHERE usuario1_id = usuario_id AND estado = 'aceptado'
    );
    
    RETURN amigos;
END$$

DROP FUNCTION IF EXISTS `obtener_historial_mensajes`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `obtener_historial_mensajes` (`usuario1_id` INT, `usuario2_id` INT) RETURNS TEXT CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE mensajes TEXT DEFAULT '';
    DECLARE mensaje_texto TEXT;
    DECLARE fecha_envio DATETIME;
    DECLARE done INT DEFAULT FALSE;  -- Declaración de la variable done
    
    -- Cursor para recorrer los mensajes entre los dos usuarios
    DECLARE mensaje_cursor CURSOR FOR
        SELECT m.contenido, m.fecha_envio
        FROM Mensajes m
        WHERE (m.remitente_id = usuario1_id AND m.destinatario_id = usuario2_id)
           OR (m.remitente_id = usuario2_id AND m.destinatario_id = usuario1_id)
        ORDER BY m.fecha_envio;
    
    -- Manejo de excepciones
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN mensaje_cursor;
    
    -- Recorremos los resultados del cursor y los almacenamos en una variable
    read_loop: LOOP
        FETCH mensaje_cursor INTO mensaje_texto, fecha_envio;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET mensajes = CONCAT(mensajes, 'Fecha: ', fecha_envio, ' - Mensaje: ', mensaje_texto, '\n');
    END LOOP;
    
    CLOSE mensaje_cursor;
    
    RETURN mensajes;
END$$

DROP FUNCTION IF EXISTS `obtener_num_publicaciones`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `obtener_num_publicaciones` (`usuario_id` INT) RETURNS INT(11) DETERMINISTIC BEGIN
    DECLARE total INT;
    
    SELECT COUNT(*) INTO total
    FROM Publicaciones
    WHERE usuario_id = usuario_id;

    RETURN total;
END$$

DROP FUNCTION IF EXISTS `obtener_publicaciones_mas_comentadas`$$
CREATE DEFINER=`root`@`localhost` FUNCTION `obtener_publicaciones_mas_comentadas` (`usuario_id` INT) RETURNS TEXT CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE publicaciones TEXT DEFAULT '';
    DECLARE post_id INT;
    DECLARE post_comentarios INT;
    DECLARE done INT DEFAULT FALSE;
    
    -- Cursor para recorrer las publicaciones y la cantidad de comentarios de cada una
    DECLARE pub_cursor CURSOR FOR
        SELECT p.id, COUNT(c.id) AS total_comentarios
        FROM Publicaciones p
        LEFT JOIN Comentarios c ON p.id = c.publicacion_id
        WHERE p.usuario_id = usuario_id
        GROUP BY p.id
        ORDER BY total_comentarios DESC;
    
    -- Manejo de excepciones
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN pub_cursor;
    
    -- Recorremos los resultados del cursor y los almacenamos en una variable
    read_loop: LOOP
        FETCH pub_cursor INTO post_id, post_comentarios;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        SET publicaciones = CONCAT(publicaciones, 'Publicación ID: ', post_id, ' - Comentarios: ', post_comentarios, '\n');
    END LOOP;
    
    CLOSE pub_cursor;
    
    RETURN publicaciones;
END$$

DELIMITER ;
