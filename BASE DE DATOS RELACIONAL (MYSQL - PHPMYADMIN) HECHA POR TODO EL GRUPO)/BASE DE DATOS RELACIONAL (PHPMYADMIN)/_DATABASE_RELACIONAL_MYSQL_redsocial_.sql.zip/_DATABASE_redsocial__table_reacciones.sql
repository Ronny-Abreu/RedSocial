
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reacciones`
--

DROP TABLE IF EXISTS `reacciones`;
CREATE TABLE `reacciones` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `publicacion_id` int(11) DEFAULT NULL,
  `comentario_id` int(11) DEFAULT NULL,
  `tipo` enum('Me gusta','Me encanta','Me divierte','Me asombra','Me entristece','Me enoja') NOT NULL,
  `fecha_reaccion` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reacciones`
--

INSERT INTO `reacciones` VALUES
(22, 1, 1, 2, 'Me gusta', '2025-03-20 17:12:54'),
(23, 2, 2, 3, 'Me encanta', '2025-03-20 17:12:54'),
(24, 3, 3, 5, 'Me divierte', '2025-03-20 17:12:54'),
(25, 4, 4, 7, 'Me asombra', '2025-03-20 17:12:54'),
(26, 5, 5, 5, 'Me entristece', '2025-03-20 17:12:54'),
(27, 6, 6, 5, 'Me enoja', '2025-03-20 17:12:54'),
(28, 7, 7, 3, 'Me gusta', '2025-03-20 17:12:54'),
(29, 8, 8, 2, 'Me encanta', '2025-03-20 17:12:54'),
(30, 9, 9, 11, 'Me divierte', '2025-03-20 17:12:54'),
(33, 12, 12, 17, 'Me enoja', '2025-03-20 17:12:54'),
(34, 13, 13, 18, 'Me gusta', '2025-03-20 17:12:54'),
(35, 14, 14, 15, 'Me encanta', '2025-03-20 17:12:54'),
(36, 15, 15, 13, 'Me divierte', '2025-03-20 17:12:54'),
(37, 16, 16, 11, 'Me asombra', '2025-03-20 17:12:54'),
(38, 17, 17, 12, 'Me entristece', '2025-03-20 17:12:54'),
(39, 18, 18, 1, 'Me enoja', '2025-03-20 17:12:54'),
(40, 19, 19, 4, 'Me gusta', '2025-03-20 17:12:54'),
(44, 1, 3, NULL, 'Me gusta', '2025-04-01 22:03:11');
